# As of 2020-4-23, the available styles are:
#     arrow
#         chevron (default)             (winxpblue, breeze)
#         solid-bg                      solid triangle with background color
#                                       (awdark, awlight, black)
#         solid                         solid triangle
#         open                          open triangle
#     button
#         (default: none)
#         roundedrect-accent-gradient   (winxpblue)
#         roundedrect-flat              (breeze)
#     checkbutton
#         roundedrect-check (default)   (awdark, awlight)
#         roundedrect-square            (breeze)
#         square-check-gradient         (winxpblue)
#         square-x                      (black)
#     combobox
#         (defaults to arrow/chevron)
#         solid-bg                      (awdark, awlight, black)
#     empty
#         empty (default)               all themes
#     entry
#         (default: none)
#         roundedrect                   (breeze)
#     labelframe
#         (default: none)
#         square                        (breeze)
#     menubutton
#         (defaults to arrow/chevron)
#         chevron                       larger than arrow/chevron
#                                       (breeze)
#         solid                         (awdark, awlight, black)
#     notebook
#         (default: none)
#         roundedtop-dark               (breeze)
#         roundedtop-light
#         roundedtop-light-accent       (winxpblue)
#     progressbar (these are used for scales and scrollbars also)
#         rect
#         rect-bord (default)           (awdark, awlight, black, winxpblue)
#         rounded-line                  (breeze)
#     radiobutton
#         circle-circle (default)       (breeze)
#         circle-circle-gradient        (winxpblue)
#         circle-circle-hlbg            (awdark, awlight)
#         octagon-circle                (black)
#     scale
#         circle                        (breeze)
#         rect
#         rect-bord-circle (default)    (awdark, awlight, black, winxpblue)
#     scrollbar-grip
#         circle (default)              (awdark, awlight, black, winxpblue)
#     sizegrip
#         circle (default)              all themes
#     treeview
#         (defaults to arrow/chevron)
#         chevron                       larger than arrow/chevron
#                                       (breeze)
#         open
#         solid                         (awdark, awlight, black)
#         plusminus-box
